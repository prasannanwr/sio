<?php
return [
    'welcome1' => 'آمن وأسرع.',
    'welcome2' => 'خدمات لوجستية والمزيد',
    'ship_quote_header' => 'احسب عرض الشحن',
    'eu_fund_quote_header' => 'احسب عرض تحويل الأموال للاتحاد الأوروبي',
    'intl_fund_quote_header' => 'احسب عرض تحويل الأموال',
    'ship_from' => 'الشحن من المدينة',
    'ship_to' => 'الشحن إلى المدينة',
    'proceed' => 'المتابعة',
    'refresh' => 'تحديث',
    '1' => 'يتم حساب معدل الشحن من',
    '2' => 'للحصول على عرض الأسعار، يرجى المتابعة لتحديد طبيعة الحزم التي ترغب في شحنها أدناه. اضغط على "إضافة عنصر" لإضافة العناصر إلى القائمة، ثم اضغط على "احصل على الأسعار المتاحة" للحصول على عروض الأسعار بناءً على العناصر التي تقوم بتكوينها.',
    '3' => 'نوع الحزمة',
    '4' => 'الطول (سم)',
    '5' => 'العرض (سم)',
    '6' => 'الارتفاع (سم)',
    '7' => 'الوزن (كجم)',
    '8' => 'العدد / الكمية',
    '9' => 'إضافة',
    '10' => 'اختر نوع الحزمة',
    '11' => 'طرد',
    '12' => 'وثيقة',
    '13' => 'منصة',
    '14' => 'حزم',
    '15' => 'الطول الكلي',
    '16' => 'العرض الكلي',
    '17' => 'الارتفاع الكلي',
    '18' => 'الوزن الكلي',
    '19' => 'العدد الكلي / الكمية',
    '20' => 'احصل على الأسعار المتاحة',
    '21' => 'أسعار الشحن',
    '22' => 'الاسم',
    '23' => 'الموقع',
    '24' => 'الأوزان (كجم)',
    '25' => 'السعر',
    '26' => 'الأبعاد',
    '27' => 'دولة المرسل',
    '28' => 'دولة المستقبل',
    '29' => 'المبلغ المرسل',
    '30' => 'الدول',
    '31' => 'العمولة',
    '32' => 'لم يتم العثور على معدل تحويل الأموال للدول والمبلغ المحدد',
    '33' => 'عملة المرسل',
    '34' => 'عملة المستقبل',
    '35' => 'العملات',
    '36' => 'المبلغ المستلم',
    '37' => 'عدة سنوات من الخبرة',
    '38' => 'من نحن',
    '39' => 'مقدم خدمات لوجستية موثوق بها، وخدمات أخرى',
    '40' => 'يعمل مشروع SIOPAY في قلب شبكة ديناميكية ومزدهرة داخل السوق. من خلال تطبيق إدارة شامل، تحصل على الوصول إلى مجموعة من الخدمات المصممة لتمكين عملك، وتعزيز رؤيته، ومساعدتك على بناء شبكة محلية قوية.<br><br>تشمل خدمات SIOPAY المدفوعات عبر الإنترنت، شحن الطرود، SPID، البريد الإلكتروني المعتمد، التوقيعات الرقمية، الإيصالات البريدية والمصرفية، MAV/RAV، PagoPA، F24، وإدارة ضرائب المركبات. هذه الأدوات هي بوابتك للتعامل بشكل فعال وسريع مع متطلبات الشحن والدفع عبر الإنترنت.<br><br>مع SIOPAY، يمكنك إدارة عملك بكفاءة واحترافية دون الحاجة إلى حلول البرمجيات باهظة الثمن أو خدمات الشحن. تواصل معنا الآن للحصول على المزيد من التفاصيل وابدأ رحلتك نحو نمو الأعمال مع SIOPAY!',
    '41' => 'خدماتنا',
    '42' => 'خدمات الشحن',
    '43' => 'اقرأ المزيد',
    '44' => 'خدمات الدفع',
    '45' => 'إعادة تعبئة بطاقة مسبقة الدفع',
    '46' => 'نقاط الاستلام',
    '47' => 'SPDI والتوقيعات الرقمية',
    '48' => 'خدمة البريد الإلكتروني المعتمد (PEC)',
    '49' => 'بطاقة المساعدة على الطريق',
    '499' => 'تحويل الأموال',
    '50' => 'إعادة بيع التذاكر',
    '51' => 'الكهرباء والغاز',
    '52' => 'خطة الأسعار',
    '53' => 'حزم الأسعار المعقولة',
    '54' => 'الأسعار الوطنية',
    '55' => '<p>في جميع أنحاء إيطاليا</p><p>سريع</p><p>موثوق</p>',
    '56' => '<p>في جميع أنحاء أوروبا</p><p>سريع</p><p>موثوق</p>',
    '57' => '<p>في جميع أنحاء العالم</p><p>سريع</p><p>موثوق</p>',
    '58' => 'أسعار الاتحاد الأوروبي',
    '59' => 'أسعار عالمية',
    '60' => 'شركاء',
    '61' => 'شركاؤنا',
    '62' => 'الناقلون',
    '63' => 'الناقلون لدينا',
    '64' => 'مدونتنا',
    '65' => 'أحدث من المدونة',
    '66' => 'الأصل',
    '67' => 'الوجهة',
    '68' => 'الحد الأدنى',
    '69' => 'الحد الأقصى',
    '70' => 'لم يتم العثور على نتائج',
    '71' => 'يرجى ملء جميع الحقول وفقًا للحصول على الأسعار',
    '72' => 'تم تصميم خدمتنا للكهرباء والغاز لإضاءة منزلك وتحسين حياتك اليومية. نحن ملتزمون بتقديم تجربة طاقة سلسة وخالية من الإجهاد. إليك سبب تميز خدمتنا ولماذا يجب أن تفكر فينا:<br><br>1.<b>موثوقية لا مثيل لها:</b> ضمان تدفق مستمر وغير منقطع للطاقة إلى منزلك هو هدفنا الرئيسي. يمكنك الاعتماد على خدمتنا دون قلق بشأن انقطاع الكهرباء أو الانقطاع. سنظل نوفر لك خدمة ثابتة لتشغيل حياتك بثبات.<br><br>2.<b>الشفافية والوضوح:</b> المفاجآت في فواتير الطاقة ليست مريحة. نحن نشاركك النفور من التكاليف غير المتوقعة، ولهذا نقدم أسعار شفافة بدون رسوم مخفية أو بنود مربكة. هدفنا هو تمكينك من معرفة ما تدفعه ولماذا.<br><br>3.<b>دعم العملاء المخصص:</b> فريق دعم العملاء لدينا في خدمتك للرد على استفساراتك والاستماع إلى مخاوفك وتزويدك بالمساعدة السريعة والفعالة. نحن ملتزمون بإعطاء الأولوية لعملائنا وتقديم تجربة خدمة من الدرجة الأولى.<br><br>',
    '73' => '4.<b>التوفير المريح:</b> نحن ندرك أهمية تقليص نفقات الطاقة. من خلال خدمتنا للكهرباء والغاز، نقدم أسعار تنافسية وحلول مصممة خصيصًا لمساعدتك في تقليل فواتير الطاقة. لن تحصل فقط على خدمة عالية الجودة، ولكن يمكنك أيضًا توفير المال.<br><br>5.<b>التحويل السهل:</b> نحن نعرف أن تغيير مزودي الطاقة قد يبدو معقدًا، لكن مع خدمتنا، نبسط العملية برمتها، مما يجعلها خالية من المتاعب. نحن نتولى جميع التفاصيل، من التحويل إلى إلغاء مزودك السابق. هدفنا هو تسهيل الانتقال وجعل نقلك إلينا سلسًا قدر الإمكان.<br><br>عندما يتعلق الأمر بالطاقة التي تشغل حياتك، لا داعي للتسوية في الجودة والاعتمادية. اختر خدمتنا للكهرباء والغاز، وفتح الباب لخدمة عملاء جديدة وشفافية وراحة.<br><br>اتصل بنا اليوم واتخذ خطوة نحو حل طاقة أفضل وأكثر كفاءة. راحتك ورضاك يبقيان أولوياتنا.',
    '74' => 'ابدأ الآن',
    '75' => 'مزود موثوق به',
    '76' => 'يعد تحديد القياسات الدقيقة للوزن والحجم لحزمتك من الجوانب الحاسمة في عملية الشحن. تؤثر أبعاد ووزن العنصر الذي تم تعبئته مباشرة على تكلفة التسليم. التأكد من تقديم معلومات دقيقة هو خطوة بسيطة لتجنب الرسوم الزائدة أو التفاوتات في المخزون، حتى إذا كانت الأخطاء غير متعمدة. بعد تعبئة العنصر بشكل مناسب باستخدام صندوق قوي ومحمي، الخطوة التالية هي تحديد وزنه.<br><br>من المهم ملاحظة أن الوزن الذي تحدده يجب أن يشمل المواد المستخدمة للتغليف. يمكنك استخدام مقياس الحمام أو مقياس الطرود لهذا الغرض. لقياس الطرود أو المنصات بشكل صحيح، اتبع هذه الإرشادات الأساسية حسب نوع الطرد. يجب أن يتم التعبير عن القياسات بالسنتيمترات، ويتم تقريبه إلى أقرب سنتيمتر.<br><br>',
    '77' => 'ومع ذلك، عند إرسال جسم ضخم بشكل غير عادي، سيتم تطبيق قاعدة الوزن الحجمي (أو الوزن المكافئ) وتحديد الشحن بناءً على الحجم، وليس الوزن الفعلي.<br><br>إن اتباع هذا التوجيه البسيط يضمن لك نقل سلس للمنتجات وحل اللوجستيات دون مفاجآت غير سارة في الأسعار.<br><br>',
    '78' => "حزمة منتظمة
لتوضيح الأمر، الصندوق المربع تمامًا، دون صعوبة كبيرة، سنقوم بقياس الجوانب الثلاثة، بغض النظر عن اتجاه الحزمة.
",
'79' => "حزمة (الشكل) غير منتظمة
يجب أخذ القياسات مع اعتبار متوازي المستطيلات الذي يحتوي تمامًا على الحزمة، وبالتالي أيضًا الجوانب المشوهة أو الزوايا البارزة.
",
'80' => "بالت
يجب أخذ القياسات مع اعتبار متوازي المستطيلات الذي له قاعدة مساوية لحجم البالتة والارتفاع اللازم لاحتواء أعلى حزمة تمامًا.
",
'81' => "حزمة (الشكل) أسطوانية
يجب أخذ القياسات مع اعتبار جانبيين يتطابقان مع قطر الدائرة والجانب الثالث يتطابق مع الارتفاع.
",
'82' => "التغليف المناسب خطوة حاسمة لضمان سلامة وأمان وصحة منتجاتك أثناء النقل. من الضروري أيضًا حمايتها من تأثير العوامل الجوية. عملية التعبئة جزء أساسي من عملية الشحن وغالبًا ما يتم التقليل من أهميتها، حيث يعتقد البعض أنها ليست عاملاً مهمًا في الخسائر أو الأضرار التي قد تحدث للمحتويات.
<br><br>
يعد التعبئة الدقيقة والمجدية أمرًا أساسيًا للحفاظ على المحتويات من الخسائر أو الأضرار. لذلك، من الضروري اتباع التعليمات التي نقدمها بدقة. بمجرد أن تكون العناصر معبأة بشكل صحيح، من المهم أن تضع عليها جميع الملصقات المطلوبة وتأكد من وضوحها وقابليتها للقراءة. حتى في حالة الأشياء مثل الأمتعة أو الهدايا التي قد تحتوي بالفعل على تعبئة خارجية، من المستحسن وضعها داخل صندوق إضافي للحفاظ على محتوياتها.
",
'83' => "مواد التعبئة
هناك العديد من المواد التي يمكن استخدامها لإنشاء تعبئة صحيحة وقوية وآمنة، وبالطبع يجب اختيار المادة الأكثر ملاءمة لنوع الشحن الذي تريد إرساله.

<ul>
    <li>لف الفقاعات</li>
    <li>شريط لاصق</li>
    <li>ورق كرافت</li>
    <li>فيلم تمديد</li>
    <li>كرتون عسل</li>
    <li>رقائق بوليسترين</li>
    <li>صندوق كرتوني</li>
</ul>
",
'84' => "المنتجات التي تحتوي على سوائل
لشحن العناصر التي تحتوي على سوائل، يجب استخدام صناديق خشبية قوية. سواء كان الوعاء زجاجيًا أو بلاستيكيًا، يجب وضع الوعاء بشكل عمودي باستخدام ختم داخلي وغطاء. علاوة على ذلك، يجب فصل الزجاجات عن بعضها البعض في جميع الأوقات.
داخل التعبئة باستخدام الكرتون أو المواد المقاومة للصدمات. بدلاً من ذلك، يمكن أيضًا استخدام صناديق كرتونية قوية (Secure Pack) التي تتكيف مع جميع أنواع الزجاجات.
",
'85' => "الأشياء ذات الأشكال غير المنتظمة
لضمان سلامة العمال، يجب تعبئة العناصر ذات الأشكال غير العادية (ذات الحواف أو النقاط) بمواد مختلفة. <br> يجب حماية المنتجات الثقيلة دائمًا باستخدام لف الفقاعات أو مواد التعبئة، ويجب وضعها في صناديق معززة أو وضعها على البالتات مع تأمينها بالحبال أو صناديق خشبية خاصة.
",
'86' => "تعبئة الأجهزة الكمبيوتر
لإرسال المواد الإلكترونية أو المماثلة، يجب استخدام المطاط الرغوي أو بوليسترين حسب وزن وحجم البضائع. <br> بمجرد اكتمال التعبئة، يجب وضع البضائع داخل حاويات ذات أبعاد مناسبة (صناديق كرتونية أو صناديق خشبية).
",
'87' => "تعبئة المواد الورقية
لتعبئة المواد الورقية مثل الصحف، المنشورات، رزم الورق أو الكتيبات، يجب استخدام مواد تعبئة ويجب وضع البضائع في صناديق مستندات أو أكياس بلاستيكية مقاومة للصدمات.
",
'88' => "تعبئة العناصر كبيرة الحجم
تتطلب الأشياء مثل الدراجات الهوائية، الأثاث، الأنابيب تعبئة خاصة لمنعها من الانحناء أو التلف أثناء النقل. <br> لهذا السبب نوصي بتقليص حجم الشحنة قدر الإمكان عن طريق إزالة كل جزء قابل للإزالة، ولفه بمواد التعبئة ووضعه داخل الصندوق. <br> التحضير الجيد للبضائع والتعبئة سيسهل النقل وسلامة البضائع، كما يمثل توفيرًا اقتصاديًا كبيرًا.
",
'89' => "تعبئة البراميل والأسطوانات
لتعبئة البراميل أو الأسطوانات التي تحتوي على سوائل أو مساحيق، يجب تأمينها على البالتة بسبب وزنها الزائد. تأكد من أن الوزن لا يتجاوز الحد الذي تتحمله البالتة واستخدم مواد كرتونية مقاومة للصدمات أو مواد خشبية بين البراميل، تحت الأحزمة أو الأحزمة لتثبيت الحمولة. أخيرًا، تأكد من أن الحمولة مركزة قدر الإمكان في مركز البالتة.
",
'90' => "تعبئة صندوق واحد
<ul>
    <li>استخدم صندوق كرتوني جديد بشكل متوازي المستطيلات، معتمد على الوزن المراد شحنه، مع ما لا يقل عن طبقتين مموجتين مقاومين وملائمين للبضائع التي سيتم شحنها. أثناء النقل، قد تتكدس حزم أخرى فوق حزمة الشحن الخاصة بك.</li>
    <li>إذا كنت تعيد استخدام صندوق، قم بإزالة جميع الملصقات والرموز الشريطية الموجودة، يجب أن يحتوي الصندوق على أسطح خالية حتى يتمكن الناقل من وضع وثائق النقل.</li>
</ul>
",
'91' => "<ul>
    <li>قم بحماية كل جانب داخليًا بما لا يقل عن 5 سم من مادة مقاومة للصدمات واملأ أي مساحة فارغة داخل الصندوق باستخدام بوليسترين أو مادة تعبئة أخرى. سيساعد ذلك في تجنب الأضرار الناجمة عن الاصطدامات بين المنتجات ويحميها من الصدمات والاهتزازات الناتجة عن الضغوط الخارجية أثناء النقل.</li>
    <li>أغلق الحزم جيدًا باستخدام شريط التعبئة أو شريط لاصق قوي، من المهم تطبيق طبقة على طول الفتحة بالكامل.</li>
    <li>تأكد من عدم وجود أجزاء بارزة أو نقاط حادة على الحزمة لتجنب كسر الصندوق.</li>
</ul>
",
'92' => "التعبئة باستخدام البالتة
<ul>
    <li>اختر بالته جيدة الجودة، غير تالفة أو رطبة في أي مكان. يمكن أن تعرض البالتات التالفة الشحنة الخاصة بك والشحنات الأخرى، وكذلك موظفي النقل للخطر.</li>
    <li>رتب الحزم على البالتة في عمود لتشكيل هيكل ثابت وقوي. يجب أن تتناسب الصناديق تمامًا داخل البالتة دون أن تتجاوز الحافة.</li>
    <li>قم بتأمين كل شيء إلى البالتة باستخدام لف وتغليف باستخدام فيلم التمديد، لتشكيل وحدة غير قابلة للفصل. يجب أن يتضمن التغليف البالتة نفسها.</li>
    <li>بعد تعبئة البضائع بشكل صحيح، من المهم جدًا طباعة وتثبيت وثيقة الشحن على الحزم!</li>
    <li>ضع الملصقات بطريقة واضحة وملحوظة، أثناء النقل يمكن تكديس البالتات، لذا يجب أن تكون الملصقات على الجوانب وليس على السطح العلوي.</li>
</ul>
",
'93' => "تعبئة حقيبة السفر
<ul>
    <li>لف الأمتعة بما لا يقل عن ثلاث لفات من الفيلم الشفاف وربط نهاية الفيلم بمقبض أو يد الحقيبة.</li>
    <li>بعد تعبئة البضائع، تذكر طباعة وإرفاق وثيقة الشحن على حزم الشحن.</li>
    <li>ضع الوثيقة على جانب مرئي بوضوح من الحقيبة.</li>
</ul>
",
'94' => "تعبئة البضائع الهشة
<ul>
    <li>بالنسبة للأشياء الهشة، استخدم دائمًا صناديق مزدوجة الجدران لحماية المنتجات من الصدمات والحفاظ على صلابتها، حتى إذا تم تكديسها فوق بعضها.</li>
    <li>ضع مادة تعبئة أسفل وفوق وعلى جوانب الكائن الهش بسمك لا يقل عن 5 سم بحيث يبقى الكائن في وسط الصندوق.</li>
    <li>استخدم دائمًا وسائد من الرغوة تتكيف بشكل مثالي مع شكل الكائن، مما يحميه من الصدمات. ضع واحدة فوقه وأخرى تحته.</li>
</ul>
",
'95' => "تعبئة اللوحات
<ul>
    <li>إذا كانت اللوحة محمية بزجاج، قم بإرفاق شريط لاصق ورقي عليها، مشكلاً حرف 'X' للحفاظ على الزجاج معًا إذا انكسر أثناء النقل.</li>
    <li>ضع طبقة من لف الفقاعات الكبيرة على سطح وقم بوضع الجزء الأمامي للوحة عليه، وهو الجزء الأكثر حساسية، ولف اللوحة بالكامل مع طبقتين على الأقل من لف الفقاعات.</li>
    <li>استخدم زوايا من البولي إيثيلين الموسع منخفض الكثافة لحماية الزوايا من الصدمات.</li>
    <li>أدخل اللوحة في حاويات معيارية مصنوعة من كرتون مزدوج الطبقات مع حشوة داخلية.</li>
</ul>
",
'96' => "01. قارن واختر
بمجرد تسجيل الدخول، يمكنك اختيار طلب جديد من القائمة الجانبية. في صفحة الطلب الجديد، حدد المدينة أو البلدية التي <b>تشحن منها</b> و<b>إلى أين تشحن</b>.
<br><br>
يمكنك البحث عن المواقع حسب <b>أسمائها</b> أو <b>رمزها البريدي (الرمز البريدي)</b>.
<br><br>
بعد تحديد مكان <b>الشحن من</b> و<b>إلى</b>، تابع لتحديد توزيع
الطرد الخاص بك. حدد نوع الطرد، الوزن، الطول، العرض، الارتفاع والكمية. يمكنك تحديد العديد من الطرود التي تريدها.
<br><br>
بعد تحديد توزيع الطرود، اضغط على <b>احصل على أسعار الشحن</b>، وستحصل على
قائمة بخطط الشحن بناءً على معايير طردك. اختر خطة بالنقر على المربع الموجود على يسار القائمة.
<br><br>
بعد اختيار خطة الشحن، يمكنك متابعة ملء تفاصيل الشحن وحفظ الطلب.
<br>
إذا تم حفظ الطلب بنجاح، ستتمكن من رؤية قائمة طلباتك، وتابع بالنقر على الدفع، ثم في الصفحة التالية املأ تفاصيل الدفع الخاصة بك.
<br>
بمجرد نجاح الدفع، يتم تأكيد طلبك.
",
'97' => "02. طباعة الملصق
على صفحة قائمة الطلبات الخاصة بي، يمكنك طباعة الملصق لطلبك، ثم تعبئة الطلب مع الملصق باتباع الإرشادات المحددة
",
'98' => "03. انتظار الناقل
بناءً على تاريخ الاستلام الذي حددته للطرود، سيقوم الناقل بجمع الطرد في اليوم المحدد في العنوان المحدد كنقطة انطلاق.
<br><br>
سلم الطرود، مجهزة بوثيقة الشحن، للناقل الذي في انتظارك على جانب الطريق.
<br><br>
سيتم جمع الطرود باستخدام وسيلة النقل المناسبة لنوع ووزن وحجم الطرود.
",
'99' => "<h2>04. تتبع الشحنة</h2> 
    <p>
        من هذه اللحظة ستكون شحنتك موجودة في أنظمة شركة النقل المسؤولة.
        يمكنك مراقبة حالتها من خلال.
        <br>
        - التوجه إلى صفحة حسابك واختيار طلباتي ثم النقر على <b>عرض/تتبع</b>.
    </p>",

    '100' => "<p class=\"fs-1 mb-5\">
        يقدم SIOPAY مجموعة شاملة من خدمات الدفع المصممة لتحسين تجربة التسوق للأعمال التجارية والعملاء. 
        تشمل خدماتنا طيفًا واسعًا من الخدمات، بما في ذلك شحن الهواتف، دفع الفواتير، بطاقات الهدايا، المحتوى الرقمي، وشحن الحسابات. 
        بفضل حلولنا الشاملة، يمكن لعملائك الاستمتاع بمدفوعات سريعة وآمنة، دون الحاجة إلى المرور بعمليات المصادقة المعقدة.
        <br><br>
        إن التزامنا بتقديم خدمات دفع عالية الجودة ومتطورة تقنيًا يجعل من SIOPAY أداة أساسية للشركات التي تسعى لتقديم مجموعة متنوعة من المنتجات وفقًا للمعايير الرقمية المتقدمة.
        باختيارك لـ SIOPAY، يمكن لشركتك توسيع نطاقها وإرضاء قاعدة عملاء متنامية وسعيدة، من خلال تقديم خدمات مبتكرة ومتقدمة.
        <br><br>
        قم بترقية عملك وإضافة قيمة لعروضك من خلال اختيار SIOPAY كحل لخدمات الدفع. فريقنا من الخبراء دائمًا في الخدمة لتقديم الدعم الفني والمساعدة الشخصية. 
        اتصل بنا اليوم لمعرفة المزيد حول كيفية تحسين تجربة تسوق عملائك من خلال خدمات الدفع المتقدمة التي نقدمها.
        <br><br>
        علاوة على ذلك، فإن خدماتنا للدفع مرنة للغاية، تم تصميمها لتلائم المتطلبات الفريدة لعملك. نحن نقدم مجموعة واسعة من خيارات الدفع، بما في ذلك بطاقات الائتمان والخصم، التحويلات البنكية، والدفع النقدي. 
        هذه المرونة تمكن عملائك من اختيار طريقة الدفع المفضلة لديهم، مما يوفر لك القدرة على تقديم الراحة والخيارات.
        <br><br>
        خدماتنا مصممة لتكون سهلة الاستخدام، مما يضمن إمكانية الوصول حتى لأولئك الأقل خبرة في المدفوعات الرقمية. نحن نوفر لعملائنا أدوات إدارة حسابات بديهية ومباشرة، مما يتيح لهم إدارة خدماتهم بشكل مستقل وبسهولة.
        <br><br>
        ثق في SIOPAY لخدمات الدفع الخاصة بك واكتشف فوائد حلنا الشامل. اتصل بنا الآن لمزيد من المعلومات واكتشاف كيفية تعزيز نمو عملك بينما نُحسن تجربة التسوق لعملائك.
    </p>",

    '101' => "<p class=\"fs-1 mb-5\">
        الـ PEC (البريد الإلكتروني المعتمد) هو خدمة توفر الأمان والصلاحية القانونية للبريد الإلكتروني الذي ترسله، مما يضمن دليلاً لا يمكن دحضه لكل من إرسال واستلام الرسائل. 
        هذه الخدمة في غاية الأهمية بالنسبة للشركات والمهنيين الذين يبحثون عن طريقة آمنة ومعترف بها قانونيًا لإرسال الوثائق الهامة.
        <br><br>
        توفر منصتنا لـ PEC حلاً موثوقًا وسهلاً لإدارة اتصالات البريد الإلكتروني المعتمدة. وهي تتكامل بسلاسة مع خدمات البريد الإلكتروني الرئيسية، مما يضمن تجربة سهلة وسلسة. 
        بالإضافة إلى ذلك، نقدم مجموعة من الخدمات التكميلية، بما في ذلك إدارة عناوين البريد الإلكتروني، التخزين الآمن، وإرسال الرسائل المعتمدة.
        <br><br>
        يعتبر PEC الخيار الأمثل للأفراد والشركات الذين يتطلعون إلى إدارة مراسلاتهم المهنية بشكل فعال. مع منصتنا، يمكنك إرسال الوثائق القانونية والعقود بطريقة آمنة وسريعة، وتلقي تأكيدات بالتسليم وقراءة الرسائل، والحفاظ على أرشيف منظم لمراسلاتك.
    </p>",

    '102' => "<p class=\"fs-1 mb-5\">
        إذا كنت من الشركات المحلية أو الشركات التي تبحث عن طريقة مريحة وآمنة لتعزيز الخدمات التي تقدمها لعملائك، فإن التعاون معنا هو الحل المثالي لك.
        <br> <br>
        خدمة شحن وتجميع مريحة وآمنة
        <br> <br>
        الطلب على خدمات الشحن والتجميع، خاصة للشراء عبر الإنترنت، في تزايد مستمر. من خلال شراكتك معنا، يمكنك تقديم خيار لعملائك لإرسال واستلام الطرود مباشرة من منشأتك، مما يلغي عناء التوصيل إلى المنازل أو الاستلام من نقاط التجميع البعيدة.
        <br> <br>
        نحن نقدم دعمًا شاملاً في تنفيذ خدمة الشحن والتجميع داخل عملك، مما يضمن تجربة سلسة ومريحة لعملائك.
        <br> <br>
        زيادة رؤية عملك من خلال خدمة الشحن والتجميع
        <br> <br>
        إن تقديم هذه الخدمة لا يضيف فقط قيمة لعملائك، بل يزيد أيضًا من رؤية عملك، مما يجذب عملاء جدد. سيقدر عملاؤك راحة إرسال واستلام الطرود خلال ساعات العمل المعتادة لمتجرك، مما يلغي الحاجة للبحث عن نقاط تجميع منفصلة.
        <br> <br>
        دعم العملاء المخصص والمهني
        <br> <br>
        إن التزامنا يشمل تقديم دعم عملاء مخصص واحترافي، مما يضمن أقصى درجات الرضا والولاء من عملائك. نحن دائمًا في خدمتك، سواء كان ذلك للحصول على مساعدة فنية أو للإجابة على استفساراتك بشأن خدماتنا.
        <br> <br>
        أسعار تنافسية لإدارة الطرود
        <br> <br>
        لا يتطلب أن تصبح نقطة تجميع استثمارًا كبيرًا في البداية، ويمكنك الاستفادة من الأسعار التنافسية لإدارة الطرود، مما يتيح لك تقديم خدمة عالية الجودة بأسعار معقولة.
        <br> <br>
        في عالم يركز بشكل متزايد على الراحة والسرعة، يمكن أن يكون التحول إلى نقطة تجميع قرارًا استراتيجيًا لعملك. لا تفوت الفرصة لتعزيز عملك - اتصل بنا الآن لمزيد من المعلومات وابدأ في تعاوننا فورًا.
    </p>",
    '103' => "<p class=\"fs-1 mb-5\">
        Prepaid cards offer a practical and hassle-free solution for handling your everyday
        expenses, especially in the realm of online purchases. However, knowing how to top up your
        prepaid card is crucial to ensure it remains usable even when your balance is depleted. This
        page provides you with a simple and swift guide on how to replenish your prepaid card.
        <br><br>
        First and foremost, it's advisable to select a prepaid card that offers favorable terms,
        including low management costs and wide acceptance across various networks. Once you've
        chosen your card, there are several methods available for topping it up. One of the most
        common and convenient options is to reload your card online through your credit institution
        or bank's website. Typically, this method is free and ensures immediate processing.
        <br><br>
        Alternatively, you can opt to reload your card in person at a bank branch or a designated
        tobacconist's office. Keep in mind that these methods may involve additional charges and
        might take a few business days to process your transaction.
        <br><br>
        To ensure the utmost security during top-up procedures, it is vital to refrain from
        disclosing personal or financial information to unfamiliar websites or individuals. Always
        use secure internet connections and safeguard your personal data.
        <br><br>
        Lastly, it's important to remember that while prepaid cards are a valuable financial tool,
        they should not entirely replace your traditional bank account. Exercise caution in using
        them and manage your finances prudently to avoid any unexpected surprises.
        <br><br>
        In conclusion, if you seek a straightforward and convenient approach to managing your
        finances, prepaid cards are undeniably an excellent choice. The process of reloading them is
        both quick and easy, and with the information provided on this page, you'll have all the
        guidance you need to do so in a secure and convenient manner. </p>
    ",

    '104' => "<p class=\"fs-1 mb-5\">
        Professional and Prompt Roadside Assistance

        <br><br>
        Are you in need of roadside assistance? Look no further! We are here to lend a helping hand.
        Our roadside assistance service is both professional and prompt, and it's available 24 hours
        a day, 7 days a week.

        <br><br>
        Swift and Decisive Response
        Thanks to our extensive network of experts and well-equipped emergency vehicles, we have the
        capability to respond swiftly and decisively in the event of breakdowns, accidents, or any
        road-related issues.
        <br><br>
        Support Wherever You Are
        No matter where you find yourself, we are always right by your side, ready to provide the
        support you require.
        <br><br>
        Travel with Complete Peace of Mind
        Opt for the tranquility and reliability of our Roadside Assistance service, and you can
        travel with complete peace of mind, knowing that help is just a call away.
        <br><br>
        Discover Our Cards!
        Explore our various card options to unlock additional benefits and extended coverage. Your
        journey is important to us, and we're here to make it as smooth and secure as possible.

    </p>",

    '105' => "<p class=\"fs-1 mb-5\">
        We provide a comprehensive array of shipping services,
        which encompass standard shipping, express delivery, and next-day service.

        <br><br>
        Our shipping platform seamlessly integrates with leading shipping companies to ensure you
        benefit
        from competitive rates and swift delivery times. Furthermore, we offer flexible shipping
        options that
        cater to your specific requirements, such as scheduling deliveries at precise times or
        designating
        specific business days for shipping.

        <br><br>
        Our user-friendly shipping platform centralizes all your shipping needs, allowing you to
        effortlessly manage your shipments. You can generate shipping labels, track the real-time
        status of your shipments, and stay informed with live updates on delivery progress.
        Moreover, our dedicated customer support team is readily available to address any queries or
        concerns you may have about your shipments.

        <br><br>
        Security is of utmost importance within our shipping services. We include product insurance
        with all our shipments to safeguard your products, ensuring they reach their destination in
        perfect condition. Additionally, we've established stringent security protocols to guarantee
        the safe and professional handling of your goods throughout the entire shipping process.

        <br><br>
        We take pride in offering a top-tier, convenient, and dependable shipping solution to our
        valued customers across Europe. Choose our shipping platform to guarantee the swift,
        trustworthy, and secure delivery of your products.

    </p>",
    '106' => "<p class=\"fs-1 mb-5\">
        In an increasingly digitalized world, the utilization of secure and dependable tools for
        managing online activities has become essential. Two pivotal technologies in this realm are
        SPID (Public Digital Identity System) and digital signatures, which play a significant role
        in ensuring data security and expediting online operations.
        <br><br>
        SPID, an acronym for Public Digital Identity System, serves as a unique identification
        system that grants access to online services provided by both public administrations and
        select private companies. This eliminates the need to create separate accounts for each
        service, simplifying the process for users. With SPID, individuals can access various public
        services, including requesting certificates, submitting applications for tenders and
        competitions, checking their contribution status, and more. Furthermore, many private
        companies have also opted to integrate SPID, making it easier for their customers to access
        online services.
        <br><br>
        Conversely, the digital signature is a tool that allows the application of a legally valid
        electronic signature to digital documents, without the necessity of printing and manually
        signing them. The digital signature holds the same legal standing as a handwritten signature
        and can be employed in diverse contexts, such as signing contracts, filing tax returns, and
        exchanging documents among individuals.
        <br><br>
        The use of SPID and digital signatures simplifies, accelerates, and most importantly,
        enhances the security of online activities. However, the specific utilization of these tools
        depends on the context. Accessing public services through SPID, for instance, entails
        registering with the system and subsequently verifying one's identity through an authorized
        digital identity provider. In the case of a digital signature, possessing a digital
        certificate and specific electronic signature software is necessary.
        <br><br>
        In any scenario, the decision to employ SPID and digital signatures represents a pivotal
        stride toward digitalizing processes and streamlining day-to-day activities. Moreover, it
        makes a tangible contribution to safeguarding the security and privacy of one's online data.
    </p>",
    '107' => "<p class=\"fs-1 mb-5\">
        Welcome to our train ticket resale agency, where we simplify your train travel experience
        throughout Europe. Our core mission is to provide an efficient and trustworthy service that
        streamlines the process of purchasing train tickets for your journeys.
        <br><br>
        We offer a comprehensive selection of tickets for destinations across Europe, encompassing
        high-speed trains, regional routes, and international connections. With our user-friendly
        online platform, you have the flexibility to make reservations at your convenience, no
        matter where you are. Furthermore, our team of experts is readily available to assist you at
        every step of the ticket booking process.
        <br><br>
        We hold your security and privacy in high regard. Therefore, all transactions conducted on
        our platform are safeguarded by state-of-the-art security measures, ensuring the utmost
        protection of your personal and financial information.
        <br><br>
        In addition, we take pride in delivering competitive prices and exclusive promotions to our
        valued customers. This not only allows you to save on your journeys but also ensures you can
        travel in comfort and style, courtesy of our luxurious onboard amenities, including
        complimentary Wi-Fi, power outlets, and onboard dining services.
        <br><br>
        Whether you're embarking on a business trip, planning a vacation, or simply seeking a
        stress-free travel experience, we're here to assist you in finding the tickets that best
        cater to your needs.
        <br><br>
        For any inquiries or assistance, our dedicated customer support team is at your service. We
        are committed to ensuring that your train journeys across Europe are comfortable, secure,
        and hassle-free.
        <br><br>
        Place your trust in us for all your European train travel requirements. Thank you for
        selecting our train ticket resale agency, and we wish you a wonderful journey!
    </p>",
    '108' => "<p class=\"fs-1 mb-5\">
        <h4>SIOPAY: The Project to Fuel Your Business Growth</h4>

        The SIOPAY project operates at the heart of a dynamic and thriving network within the
        market. With our comprehensive management application, you gain access to a range of
        services designed to empower your business, enhance its visibility, and help you establish a
        robust local network.
        <br><br>
        SIOPAY's service offerings encompass online payments, parcel shipping, SPID, certified
        electronic mail, digital signatures, postal and bank slips, MAV/RAV, PagoPA, F24, and
        vehicle tax management. These tools are your gateway to efficient and speedy handling of
        your online shipping and payment requirements.
        <br><br>
        When it comes to utilizing SIOPAY, you don't need to be a payment expert; all you need is
        the drive for business growth and a desire to be part of a continually evolving
        entrepreneurial project. Our user-friendly and efficient management system simplifies the
        process, allowing you to focus on expanding your business.
        <br><br>
        Additionally, the SIOPAY project presents the opportunity to forge valuable local
        connections through partnerships with fellow entrepreneurs involved in the project. This
        collaborative effort enables you to extend your reach and connect with a broader pool of
        potential customers.
        <br><br>
        In summary, if your goal is to expand your business and boost its visibility, SIOPAY stands
        as the ideal solution for you. Join us, and you'll discover a multitude of advantages
        available through our management application.
        <br><br>
        With SIOPAY, you can efficiently and professionally manage your business without the need
        for costly software solutions or shipping services. Contact us now for more details and
        embark on your journey to business growth with SIOPAY!
    </p>",

    '109' => "<p class=\"fs-1 mb-5\">
        We would like to inform you that some goods cannot be shipped due to security reasons,
        international laws and regulations. These include, for example, dangerous substances,
        weapons, drugs, live animals and illegal objects. We invite you to consult our complete list
        of prohibited goods before proceeding with sending any package. Your safety and that of our
        couriers are our top priority.
        <br><br>
        It is also important to remember that shipping prohibited goods can lead to legal
        consequences and financial penalties. Before shipping, always make sure you know the
        restrictions and regulations in place to avoid future problems.
        <br><br>
        Before carrying out any shipment, it is always important to check the list of prohibited
        goods to avoid inconveniences and penalties. We are here to help you understand which items
        cannot be shipped and to provide you with useful advice on the correct management of
        shipments. Trust our experience and support to ensure safe and efficient shipments.
    </p>",
    '110' => '<h2>ANIMALS</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Dead or alive animals</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Skins or Fur</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Animal parts</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Objects containing ivories
                </font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Items containing meat</font>
            </font>
        </li>
    </ul>
    </p>',
    '111' => '<h2>VEGETABLES</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Flowers</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Tobacco</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Plant</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Topsoil</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Seeds</font>
            </font>
        </li>
    </ul>
    </p>',
    '112' => '<h2>VALUABLES</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Craftwork / Antiques</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Precious metals</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Precious stones</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Jewelery including watches
                </font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Artwork</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Items worth more than 5000
                </font>
            </font>
        </li>
    </ul>
    </p>',
    '113' => '<h2>DANGEROUS ITEMS</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Explosives</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Radioactive material</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Guns</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Swords</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Knives</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Chainsaws</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Axes</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Fireworks</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Objects with blades with a
                    diameter greater than 3 cm</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Weapons or ammunition</font>
            </font>
        </li>
    </ul>
    </p>',
    '114' => '<h2>CONTAINING OBJECTS</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Mirrors</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Crystals</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Resins</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Cement</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Marble</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Glass</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Porcelain</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Granites</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Stones</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Ceramics</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">China</font>
            </font>
        </li>
    </ul>
    </p>',
    '115' => '<h2>CORROSIVE MATERIALS</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Batteries</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">New or exhausted batteries
                </font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Lithium</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Mercury</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Hydrochloric acid</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Irritants</font>
            </font>
        </li>
    </ul>
    </p>',
    '116' => '<h2>OTHER</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Alcohol</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Personal property</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Magnets and objects
                    containing magnets</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Medicines</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Tickets</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Porcelain</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Perishable food</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Checks</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Boxes with labels bearing
                    the words “hazardous material”</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Human remains and liquids
                </font>
            </font>
        </li>
    </ul>
    </p>',
    '117' => '<h2>FLAMMABLE MATERIALS</h2>
    <p>
    <ul>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Paint</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Fire extinguishers</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Objects containing any gas
                </font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Spray cans</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Compressed air cylinders
                </font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Solvents</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Petrolium</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Perfumes</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Insecticide</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Dry ice</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Flaming resins</font>
            </font>
        </li>
        <li>
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Chemical materials</font>
            </font>
        </li>
    </ul>
    </p>',

];
