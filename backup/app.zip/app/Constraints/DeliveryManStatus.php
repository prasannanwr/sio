<?php

namespace App\Constraints;

class DeliveryManStatus
{
    public const PENDING = 'Pending';
    public const ACCEPTED = 'Accepted';
    public const ENGAGE_WITH_PARCEL = 'engage with parcel';
    public const ON_THE_WAY = 'On the way';
    public const DELIVERED = 'Delivered';
}
