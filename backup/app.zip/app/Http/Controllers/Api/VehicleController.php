<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Vehicle;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class VehicleController extends Controller
{
    public function mine(Request $request): JsonResponse
    {
        $vehicles = Vehicle::where('delivery_man_id', $request->user()->id)
            ->with('shippingCost')
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Assigned vehicles retrieved successfully.',
            'total' => $vehicles->count(),
            'data' => $vehicles->map(function (Vehicle $vehicle) {
                return $this->vehiclePayload($vehicle, true);
            })->values(),
        ]);
    }

    protected function vehiclePayload(Vehicle $vehicle, bool $includeDocuments = false): array
    {
        return [
            'id' => $vehicle->id,
            'type' => $vehicle->type,
            'brand' => $vehicle->brand,
            'model' => $vehicle->model,
            'plate_number' => $vehicle->plate_number,
            'color' => $vehicle->color,
            'year' => $vehicle->year,
            'status' => $vehicle->status,
            'shipping_rate' => $this->shippingCostPayload($vehicle),
            'documents' => $includeDocuments ? $this->documentsPayload($vehicle) : [],
            'created_at' => optional($vehicle->created_at)->toIso8601String(),
            'updated_at' => optional($vehicle->updated_at)->toIso8601String(),
        ];
    }

    protected function shippingCostPayload(Vehicle $vehicle): ?array
    {
        if (! $vehicle->shippingCost) {
            return null;
        }

        return [
            'id' => $vehicle->shippingCost->id,
            'label' => $vehicle->shippingCost->display_label,
            'weight' => $vehicle->shippingCost->weight,
            'country_name' => $vehicle->shippingCost->country_name,
            'country_iso_2' => $vehicle->shippingCost->country_iso_2,
            'cost' => $vehicle->shippingCost->cost,
        ];
    }

    protected function documentsPayload(Vehicle $vehicle): array
    {
        return collect($vehicle->documents ?: [])->map(function (array $document) {
            return [
                'name' => $document['name'] ?? basename($document['path'] ?? ''),
                'url' => ! empty($document['path']) ? asset($document['path']) : null,
                'mime' => $document['mime'] ?? null,
                'size' => $document['size'] ?? null,
                'uploaded_at' => $document['uploaded_at'] ?? null,
            ];
        })->values()->all();
    }
}
