<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ShippingController extends Controller
{
    public function calculateShipping(Request $request)
    {
        $request->validate([
            'ship_from_country' => 'required',
            'ship_from_city' => 'required',
            'ship_to_country' => 'required',
            'ship_to_city' => 'required',
            'freight_mode' => 'nullable|in:Air,Sea,Road,air,sea,road,AIR,SEA,ROAD',
            'mode' => 'nullable|in:Air,Sea,Road,air,sea,road,AIR,SEA,ROAD',
            'weightTotal' => 'required|numeric',
            'heightTotal' => 'required|numeric',
            'widthTotal' => 'required|numeric',
            'lengthTotal' => 'required|numeric',
            'valueTotal' => 'required|numeric',
            'countTotal' => 'required|numeric',
        ]);

        try {
            $freightMode = $request->input('freight_mode', $request->input('mode'));
            $freightMode = $freightMode ? ucfirst(strtolower($freightMode)) : null;

            $response = Http::timeout(30)
                ->get('https://www.sioshipping.eu/rates-fetch', [
                    'ship_from_country' => $request->ship_from_country,
                    'ship_from_city' => $request->ship_from_city,
                    'ship_to_country' => $request->ship_to_country,
                    'ship_to_city' => $request->ship_to_city,
                    'freight_mode' => $freightMode,
                    'origin' => config('app.url'),

                    'weightTotal' => $request->weightTotal,
                    'heightTotal' => $request->heightTotal,
                    'widthTotal' => $request->widthTotal,
                    'lengthTotal' => $request->lengthTotal,
                    'valueTotal' => $request->valueTotal,
                    'countTotal' => $request->countTotal,
                ]);

            if (!$response->successful()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Unable to fetch shipping rates',
                    'error' => $response->body()
                ], 500);
            }

            return response()->json([
                'status' => true,
                'message' => 'Shipping rates fetched successfully',
                'freight_mode' => $freightMode,
                'data' => $response->json()
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'status' => false,
                'message' => 'Shipping API error',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
