<?php

namespace App\Http\Controllers\Api;

use App\Constraints\OrderStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\FreightQuotationRequest;
use App\Models\Order;
use App\Models\OrderPackage;
use App\Models\ShippingRate;
use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CargoHaulageBookingController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'pickup_location_id' => 'required',
            'destination_location_id' => 'required',
            'freight_mode' => 'nullable|in:Air,Sea,Road,air,sea,road,AIR,SEA,ROAD',
            'booking_date' => 'required|date',
            'vehicle_type' => 'nullable|in:' . Vehicle::TYPE_VAN . ',' . Vehicle::TYPE_TRUCK,
            'weight' => 'required|numeric|min:0.1',
            'length' => 'nullable|numeric|min:0',
            'width' => 'nullable|numeric|min:0',
            'height' => 'nullable|numeric|min:0',
            'cargo_description' => 'required|string',
            'cargo_value' => 'nullable|numeric|min:0',
            'quantity' => 'nullable|integer|min:1',
            'pickup_name' => 'required|string',
            'pickup_phone' => 'required|string',
            'pickup_email' => 'nullable|email',
            'pickup_address1' => 'required|string',
            'pickup_address2' => 'nullable|string',
            'pickup_zip' => 'nullable|string',
            'pickup_city' => 'nullable|string',
            'pickup_state' => 'nullable|string',
            'pickup_country' => 'nullable|string',
            'delivery_name' => 'required|string',
            'delivery_phone' => 'required|string',
            'delivery_email' => 'nullable|email',
            'delivery_address1' => 'required|string',
            'delivery_address2' => 'nullable|string',
            'delivery_zip' => 'nullable|string',
            'delivery_city' => 'nullable|string',
            'delivery_state' => 'nullable|string',
            'delivery_country' => 'nullable|string',
        ]);

        $vehicle = $this->supportedCargoVehicle(
            $validated['pickup_location_id'],
            $validated['destination_location_id'],
            (float) $validated['weight'],
            $validated['vehicle_type'] ?? null
        );

        if (! $vehicle) {
            return response()->json([
                'status' => false,
                'message' => 'Cargo/haulage booking is not supported for this route, vehicle type, and cargo weight.',
            ], 422);
        }

        $rate = $this->matchingRate($validated);
        $shippingCost = $this->shippingCost($vehicle, $rate, (float) $validated['weight']);

        $order = DB::transaction(function () use ($request, $validated, $vehicle, $rate, $shippingCost) {
            $order = new Order();
            $order->customer_id = optional($request->user()->customer)->id;
            $order->dispatcher_id = $vehicle->delivery_man_id;
            $order->pickup_location_id = $validated['pickup_location_id'];
            $order->delivery_location_id = $validated['destination_location_id'];
            $order->current_location_id = $validated['pickup_location_id'];
            $order->shipping_rate_id = optional($rate)->id;
            $order->tracking_id = 'SIOCARGO' . time() . Str::upper(Str::random(6));
            $order->status = OrderStatus::UNPAID;
            $order->provider = 'SIOPAY_CARGO_HAULAGE';
            $order->freight_mode = $this->freightMode($validated);
            $order->shipping_cost = $shippingCost;
            $order->return_date = $validated['booking_date'];
            $order->cond_of_goods = 'Cargo/Haulage';
            $order->val_of_goods = $validated['cargo_value'] ?? null;

            $order->pickup_name = $validated['pickup_name'];
            $order->pickup_phone = $validated['pickup_phone'];
            $order->pickup_email = $validated['pickup_email'] ?? null;
            $order->pickup_address1 = $validated['pickup_address1'];
            $order->pickup_address2 = $validated['pickup_address2'] ?? null;
            $order->pickup_zip = $validated['pickup_zip'] ?? null;
            $order->pickup_city = $validated['pickup_city'] ?? null;
            $order->pickup_state = $validated['pickup_state'] ?? null;
            $order->pickup_country = $validated['pickup_country'] ?? null;

            $order->delivery_name = $validated['delivery_name'];
            $order->delivery_phone = $validated['delivery_phone'];
            $order->delivery_email = $validated['delivery_email'] ?? null;
            $order->delivery_address1 = $validated['delivery_address1'];
            $order->delivery_address2 = $validated['delivery_address2'] ?? null;
            $order->delivery_zip = $validated['delivery_zip'] ?? null;
            $order->delivery_city = $validated['delivery_city'] ?? null;
            $order->delivery_state = $validated['delivery_state'] ?? null;
            $order->delivery_country = $validated['delivery_country'] ?? null;
            $order->save();

            $package = new OrderPackage();
            $package->order_id = $order->id;
            $package->type = 'cargo';
            $package->length = $validated['length'] ?? 0;
            $package->width = $validated['width'] ?? 0;
            $package->height = $validated['height'] ?? 0;
            $package->weight = $validated['weight'];
            $package->qty = $validated['quantity'] ?? 1;
            $package->item_desc = $validated['cargo_description'];
            $package->item_value = $validated['cargo_value'] ?? 0;
            $package->save();

            return $order;
        });

        return response()->json([
            'status' => true,
            'message' => 'Cargo/haulage booking created successfully.',
            'data' => [
                'tracking_id' => $order->tracking_id,
                'booking_supported' => true,
                'delivery_man_id' => $vehicle->delivery_man_id,
                'vehicle_id' => $vehicle->id,
                'vehicle_type' => $vehicle->type,
                'shipping_rate_id' => optional($rate)->id,
                'shipping_cost' => $shippingCost,
            ],
        ], 201);
    }

    protected function supportedCargoVehicle($pickupLocationId, $destinationLocationId, float $weight, ?string $vehicleType): ?Vehicle
    {
        $query = Vehicle::query()
            ->where('status', Vehicle::STATUS_ACTIVE)
            ->whereIn('type', [Vehicle::TYPE_VAN, Vehicle::TYPE_TRUCK])
            ->where('origin_location', $pickupLocationId)
            ->where('destination_location', $destinationLocationId)
            ->whereNotNull('weight_range')
            ->where(function ($query) use ($weight) {
                $query->whereRaw('CAST(SUBSTRING_INDEX(weight_range, \'-\', 1) AS DECIMAL(10,2)) <= ?', [$weight])
                    ->whereRaw('CAST(SUBSTRING_INDEX(weight_range, \'-\', -1) AS DECIMAL(10,2)) >= ?', [$weight]);
            });

        if ($vehicleType) {
            $query->where('type', $vehicleType);
        }

        return $query->orderByRaw("FIELD(type, '" . Vehicle::TYPE_TRUCK . "', '" . Vehicle::TYPE_VAN . "')")
            ->first();
    }

    protected function matchingRate(array $validated): ?ShippingRate
    {
        $query = ShippingRate::query()
            ->where('origin_id', $validated['pickup_location_id'])
            ->where('destination_id', $validated['destination_location_id'])
            ->where('weight_start', '<=', $validated['weight'])
            ->where('weight_end', '>=', $validated['weight']);

        foreach (['length', 'width', 'height'] as $dimension) {
            if (isset($validated[$dimension])) {
                $query->where($dimension, '>=', $validated[$dimension]);
            }
        }

        return $query->first();
    }

    protected function shippingCost(Vehicle $vehicle, ?ShippingRate $rate, float $weight): ?float
    {
        if ($vehicle->distance_km && $vehicle->rate_per_km_per_kg) {
            return round((float) $vehicle->distance_km * (float) $vehicle->rate_per_km_per_kg * $weight, 2);
        }

        return optional($rate)->price;
    }

    protected function freightMode(array $validated): string
    {
        $mode = $validated['freight_mode'] ?? FreightQuotationRequest::MODE_ROAD;

        return ucfirst(strtolower($mode));
    }
}
