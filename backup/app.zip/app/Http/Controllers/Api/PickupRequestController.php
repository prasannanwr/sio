<?php

namespace App\Http\Controllers\Api;

use App\Constraints\OrderStatus;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderPackage;
use App\Models\ShippingRate;
use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PickupRequestController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'pickup_location_id' => 'required',
            'destination_location_id' => 'required',
            'pickup_date' => 'required|date',
            'weight' => 'required|numeric|min:0.1',
            'length' => 'nullable|numeric|min:0',
            'width' => 'nullable|numeric|min:0',
            'height' => 'nullable|numeric|min:0',
            'count' => 'nullable|integer|min:1',
            'item_desc' => 'nullable|string',
            'item_value' => 'nullable|numeric|min:0',
            'pickup_name' => 'required|string',
            'pickup_phone' => 'required|string',
            'pickup_email' => 'nullable|email',
            'pickup_address1' => 'required|string',
            'pickup_address2' => 'nullable|string',
            'pickup_zip' => 'nullable|string',
            'pickup_city' => 'nullable|string',
            'pickup_state' => 'nullable|string',
            'pickup_country' => 'nullable|string',
            'delivery_name' => 'required|string',
            'delivery_phone' => 'required|string',
            'delivery_email' => 'nullable|email',
            'delivery_address1' => 'required|string',
            'delivery_address2' => 'nullable|string',
            'delivery_zip' => 'nullable|string',
            'delivery_city' => 'nullable|string',
            'delivery_state' => 'nullable|string',
            'delivery_country' => 'nullable|string',
        ]);

        $vehicle = $this->supportedVehicle(
            $validated['pickup_location_id'],
            $validated['destination_location_id'],
            (float) $validated['weight']
        );

        if (! $vehicle) {
            return response()->json([
                'status' => false,
                'message' => 'Pickup is not supported for this route and package weight.',
            ], 422);
        }

        $rate = $this->matchingRate($validated);

        $order = DB::transaction(function () use ($request, $validated, $vehicle, $rate) {
            $order = new Order();
            $order->customer_id = optional($request->user()->customer)->id;
            $order->dispatcher_id = $vehicle->delivery_man_id;
            $order->pickup_location_id = $validated['pickup_location_id'];
            $order->delivery_location_id = $validated['destination_location_id'];
            $order->current_location_id = $validated['pickup_location_id'];
            $order->shipping_rate_id = optional($rate)->id;
            $order->tracking_id = 'SIOPICKUP' . time() . Str::upper(Str::random(6));
            $order->status = OrderStatus::UNPAID;
            $order->provider = 'SIOPAY';
            $order->shipping_cost = optional($rate)->price;
            $order->return_date = $validated['pickup_date'];

            $order->pickup_name = $validated['pickup_name'];
            $order->pickup_phone = $validated['pickup_phone'];
            $order->pickup_email = $validated['pickup_email'] ?? null;
            $order->pickup_address1 = $validated['pickup_address1'];
            $order->pickup_address2 = $validated['pickup_address2'] ?? null;
            $order->pickup_zip = $validated['pickup_zip'] ?? null;
            $order->pickup_city = $validated['pickup_city'] ?? null;
            $order->pickup_state = $validated['pickup_state'] ?? null;
            $order->pickup_country = $validated['pickup_country'] ?? null;

            $order->delivery_name = $validated['delivery_name'];
            $order->delivery_phone = $validated['delivery_phone'];
            $order->delivery_email = $validated['delivery_email'] ?? null;
            $order->delivery_address1 = $validated['delivery_address1'];
            $order->delivery_address2 = $validated['delivery_address2'] ?? null;
            $order->delivery_zip = $validated['delivery_zip'] ?? null;
            $order->delivery_city = $validated['delivery_city'] ?? null;
            $order->delivery_state = $validated['delivery_state'] ?? null;
            $order->delivery_country = $validated['delivery_country'] ?? null;
            $order->save();

            $package = new OrderPackage();
            $package->order_id = $order->id;
            $package->type = 'parcel';
            $package->length = $validated['length'] ?? 0;
            $package->width = $validated['width'] ?? 0;
            $package->height = $validated['height'] ?? 0;
            $package->weight = $validated['weight'];
            $package->qty = $validated['count'] ?? 1;
            $package->item_desc = $validated['item_desc'] ?? 'Pickup request';
            $package->item_value = $validated['item_value'] ?? 0;
            $package->save();

            return $order;
        });

        return response()->json([
            'status' => true,
            'message' => 'Pickup request created successfully.',
            'data' => [
                'tracking_id' => $order->tracking_id,
                'pickup_supported' => true,
                'delivery_man_id' => $vehicle->delivery_man_id,
                'vehicle_id' => $vehicle->id,
                'shipping_rate_id' => optional($rate)->id,
                'shipping_cost' => optional($rate)->price,
            ],
        ], 201);
    }

    protected function supportedVehicle($pickupLocationId, $destinationLocationId, float $weight): ?Vehicle
    {
        return Vehicle::query()
            ->where('status', Vehicle::STATUS_ACTIVE)
            ->where('origin_location', $pickupLocationId)
            ->where('destination_location', $destinationLocationId)
            ->whereNotNull('weight_range')
            ->where(function ($query) use ($weight) {
                $query->whereRaw('CAST(SUBSTRING_INDEX(weight_range, \'-\', 1) AS DECIMAL(10,2)) <= ?', [$weight])
                    ->whereRaw('CAST(SUBSTRING_INDEX(weight_range, \'-\', -1) AS DECIMAL(10,2)) >= ?', [$weight]);
            })
            ->first();
    }

    protected function matchingRate(array $validated): ?ShippingRate
    {
        $query = ShippingRate::query()
            ->where('origin_id', $validated['pickup_location_id'])
            ->where('destination_id', $validated['destination_location_id'])
            ->where('weight_start', '<=', $validated['weight'])
            ->where('weight_end', '>=', $validated['weight']);

        foreach (['length', 'width', 'height'] as $dimension) {
            if (isset($validated[$dimension])) {
                $query->where($dimension, '>=', $validated[$dimension]);
            }
        }

        return $query->first();
    }
}
