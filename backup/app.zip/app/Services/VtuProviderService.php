<?php

namespace App\Services;

use App\Models\VtuTransaction;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use RuntimeException;

class VtuProviderService
{
    public function services(): array
    {
        $services = [];

        foreach (config('vtu.services', []) as $code => $service) {
            $services[] = array_merge(['code' => $code], $service);
        }

        return $services;
    }

    public function providers(string $serviceType): array
    {
        if ($this->usesMockDriver()) {
            return config("vtu.providers.{$serviceType}", []);
        }

        return $this->request('providers', ['service_type' => $serviceType]);
    }

    public function products(string $serviceType, string $providerCode): array
    {
        if ($this->usesMockDriver()) {
            return config("vtu.products.{$serviceType}.{$providerCode}", []);
        }

        return $this->request('products', [
            'service_type' => $serviceType,
            'provider_code' => $providerCode,
        ]);
    }

    public function validateCustomer(array $payload): array
    {
        if ($this->usesMockDriver()) {
            return [
                'status' => true,
                'message' => 'Customer validated successfully.',
                'data' => [
                    'customer_reference' => $payload['customer_reference'],
                    'customer_name' => $payload['customer_name'] ?? 'Demo Customer',
                    'service_type' => $payload['service_type'],
                    'provider_code' => $payload['provider_code'],
                ],
            ];
        }

        return $this->request('validate_customer', $payload);
    }

    public function purchase(array $payload): array
    {
        if ($this->usesMockDriver()) {
            return [
                'status' => 'successful',
                'message' => 'VTU purchase completed in mock mode.',
                'reference' => $payload['reference'],
                'provider_reference' => 'MOCK-' . strtoupper(Str::random(12)),
                'data' => [
                    'service_type' => $payload['service_type'],
                    'provider_code' => $payload['provider_code'],
                    'product_code' => $payload['product_code'] ?? null,
                    'customer_reference' => $payload['customer_reference'],
                    'amount' => $payload['amount'],
                ],
            ];
        }

        return $this->request('purchase', $payload);
    }

    public function status(string $reference): array
    {
        if ($this->usesMockDriver()) {
            return [
                'status' => 'successful',
                'message' => 'Mock transactions complete during purchase.',
                'reference' => $reference,
            ];
        }

        return $this->request('status', ['reference' => $reference]);
    }

    public function normalizeStatus(array $response): string
    {
        $statusValue = (
            data_get($response, 'status')
            ?? data_get($response, 'transaction_status')
            ?? data_get($response, 'transactionStatus')
            ?? data_get($response, 'data.status')
            ?? data_get($response, 'responseBody.status')
            ?? data_get($response, 'responseBody.transactionStatus')
            ?? ''
        );
        $status = strtolower((string) $statusValue);

        if ($statusValue === false) {
            return VtuTransaction::STATUS_FAILED;
        }

        if (in_array($status, ['success', 'successful', 'completed', 'complete', 'delivered', 'fulfilled'], true)) {
            return VtuTransaction::STATUS_SUCCESSFUL;
        }

        if (in_array($status, ['failed', 'failure', 'declined', 'cancelled', 'canceled', 'error'], true)) {
            return VtuTransaction::STATUS_FAILED;
        }

        if (in_array($status, ['reversed', 'refunded', 'refund'], true)) {
            return VtuTransaction::STATUS_REVERSED;
        }

        if (in_array($status, ['pending', 'processing', 'in-progress', 'in_progress', 'queued'], true)) {
            return VtuTransaction::STATUS_PROCESSING;
        }

        if (data_get($response, 'success') === false
            || data_get($response, 'requestSuccessful') === false
            || data_get($response, 'data.success') === false
            || data_get($response, 'responseBody.success') === false) {
            return VtuTransaction::STATUS_FAILED;
        }

        if ((bool) data_get($response, 'success')
            || (bool) data_get($response, 'requestSuccessful')
            || (bool) data_get($response, 'data.success')
            || (bool) data_get($response, 'responseBody.success')) {
            return VtuTransaction::STATUS_PROCESSING;
        }

        return VtuTransaction::STATUS_PROCESSING;
    }

    public function providerReference(array $response): ?string
    {
        return data_get($response, 'provider_reference')
            ?? data_get($response, 'providerReference')
            ?? data_get($response, 'transaction_reference')
            ?? data_get($response, 'transactionReference')
            ?? data_get($response, 'reference')
            ?? data_get($response, 'data.provider_reference')
            ?? data_get($response, 'data.reference')
            ?? data_get($response, 'responseBody.providerReference')
            ?? data_get($response, 'responseBody.reference');
    }

    protected function request(string $endpointKey, array $payload = []): array
    {
        $endpoint = config("vtu.provider.endpoints.{$endpointKey}");

        if (! is_array($endpoint) || empty($endpoint['path'])) {
            throw new RuntimeException("VTU provider endpoint [{$endpointKey}] is not configured.");
        }

        $baseUrl = rtrim((string) config('vtu.provider.base_url'), '/');

        if ($baseUrl === '') {
            throw new RuntimeException('VTU provider base URL is not configured.');
        }

        $method = strtoupper((string) Arr::get($endpoint, 'method', 'GET'));
        $path = $this->replacePathParameters((string) $endpoint['path'], $payload);
        $url = $baseUrl . '/' . ltrim($path, '/');
        $body = $this->payloadWithoutPathParameters($payload, (string) $endpoint['path']);

        $request = Http::timeout((int) config('vtu.provider.timeout', 30))
            ->acceptJson()
            ->withHeaders($this->headers());

        $response = $method === 'GET'
            ? $request->get($url, $body)
            : $request->send($method, $url, ['json' => $body]);

        $data = $response->json();

        if (! is_array($data)) {
            $data = ['raw_response' => $response->body()];
        }

        if (! $response->successful()) {
            Log::warning('VTU provider request failed', [
                'endpoint' => $endpointKey,
                'status' => $response->status(),
                'response' => $data,
            ]);

            throw new RuntimeException(
                data_get($data, 'message', data_get($data, 'responseMessage', 'VTU provider request failed')),
                $response->status()
            );
        }

        return $data;
    }

    protected function usesMockDriver(): bool
    {
        return strtolower((string) config('vtu.provider.driver', 'mock')) === 'mock';
    }

    protected function headers(): array
    {
        $headers = [];
        $apiKey = (string) config('vtu.provider.api_key');

        if ($apiKey !== '') {
            $apiKeyHeader = (string) config('vtu.provider.api_key_header', 'Authorization');

            $headers[$apiKeyHeader] = strtolower($apiKeyHeader) === 'authorization'
                ? trim(config('vtu.provider.auth_scheme', 'Bearer') . ' ' . $apiKey)
                : $apiKey;
        }

        $secretKey = (string) config('vtu.provider.secret_key');

        if ($secretKey !== '') {
            $headers['X-Secret-Key'] = $secretKey;
        }

        return $headers;
    }

    protected function replacePathParameters(string $path, array $payload): string
    {
        return preg_replace_callback('/\{([A-Za-z0-9_]+)\}/', function ($matches) use ($payload) {
            return rawurlencode((string) data_get($payload, $matches[1], ''));
        }, $path);
    }

    protected function payloadWithoutPathParameters(array $payload, string $path): array
    {
        preg_match_all('/\{([A-Za-z0-9_]+)\}/', $path, $matches);

        foreach ($matches[1] ?? [] as $key) {
            unset($payload[$key]);
        }

        return $payload;
    }
}
