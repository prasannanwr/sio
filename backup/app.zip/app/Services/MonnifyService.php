<?php

namespace App\Services;

use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * Thin wrapper around the Monnify REST API.
 *
 * Docs: https://developers.monnify.com/api
 */
class MonnifyService
{
    protected string $baseUrl;
    protected string $apiKey;
    protected string $secretKey;
    protected string $contractCode;

    public function __construct()
    {
        $this->baseUrl      = rtrim(trim((string) config('monnify.base_url')), '/');
        $this->apiKey       = trim((string) config('monnify.api_key'));
        $this->secretKey    = trim((string) config('monnify.secret_key'));
        $this->contractCode = trim((string) config('monnify.contract_code'));
    }

    /**
     * Get a Bearer access token. Tokens last ~1 hour, so we cache for 50 minutes.
     */
    public function getAccessToken(bool $forceRefresh = false): string
    {
        $this->ensureConfigured();

        $cacheKey = 'monnify.access_token';

        if ($forceRefresh) {
            Cache::forget($cacheKey);
        }

        return Cache::remember($cacheKey, now()->addMinutes(50), function () {
            $credentials = base64_encode("{$this->apiKey}:{$this->secretKey}");

            $response = Http::withHeaders([
                'Authorization' => "Basic {$credentials}",
                'Content-Type'  => 'application/json',
            ])->post("{$this->baseUrl}/api/v1/auth/login");

            if (! $response->successful() || ! $response->json('requestSuccessful')) {
                $responseCode = $response->json('responseCode') ?: $response->status();
                $responseMessage = trim((string) $response->json('responseMessage'));

                Log::error('Monnify auth failed', [
                    'base_url' => $this->baseUrl,
                    'status' => $response->status(),
                    'response_code' => $responseCode,
                    'response_message' => $responseMessage,
                    'response' => $response->body(),
                ]);

                $details = $responseMessage !== ''
                    ? $responseMessage
                    : 'responseCode ' . $responseCode;

                throw new RuntimeException(
                    'Could not authenticate with Monnify (' . $details . '). '
                    . 'Check MONNIFY_BASE_URL, MONNIFY_API_KEY, and MONNIFY_SECRET_KEY belong to the same Monnify environment.'
                );
            }

            return $response->json('responseBody.accessToken');
        });
    }

    /**
     * Initialize a transaction. Returns the checkout URL + transaction reference.
     *
     * @param  array{
     *   amount: float|int,
     *   customerName: string,
     *   customerEmail: string,
     *   paymentReference: string,
     *   paymentDescription?: string,
     *   currencyCode?: string,
     *   redirectUrl?: string,
     *   paymentMethods?: array<string>,
     *   metadata?: array<string,mixed>,
     * } $payload
     */
    public function initializeTransaction(array $payload): array
    {
        $body = [
            'amount'             => $payload['amount'],
            'customerName'       => $payload['customerName'],
            'customerEmail'      => $payload['customerEmail'],
            'paymentReference'   => $payload['paymentReference'],
            'paymentDescription' => $payload['paymentDescription'] ?? 'Payment',
            'currencyCode'       => $payload['currencyCode'] ?? config('monnify.currency'),
            'contractCode'       => $this->contractCode,
            'redirectUrl'        => $payload['redirectUrl'] ?? config('monnify.redirect_url'),
        ];

        $paymentMethods = $this->paymentMethods($payload['paymentMethods'] ?? null);

        if (! empty($paymentMethods)) {
            $body['paymentMethods'] = $paymentMethods;
        }

        if (! empty($payload['metadata']) && is_array($payload['metadata'])) {
            $metadata = $this->metadata($payload['metadata']);

            if (! empty($metadata)) {
                $body['metaData'] = $metadata;
            }
        }

        return $this->request('POST', '/api/v1/merchant/transactions/init-transaction', $body);
    }

    /**
     * Monnify treats paymentMethods as optional and defaults to the available
     * methods on the merchant account, so only send it when the caller chooses.
     *
     * @param  array<string>|null  $paymentMethods
     * @return array<int,string>
     */
    protected function paymentMethods(?array $paymentMethods): array
    {
        if (empty($paymentMethods)) {
            return [];
        }

        return array_values(array_unique(array_filter(array_map(function ($method) {
            return is_string($method) ? trim($method) : null;
        }, $paymentMethods))));
    }

    /**
     * Keep Monnify metadata flat. Nested arrays can trigger Monnify's generic
     * malformed syntax response, while our local records keep the rich metadata.
     *
     * @param  array<string,mixed>  $metadata
     * @return array<string,mixed>
     */
    protected function metadata(array $metadata): array
    {
        $normalized = [];

        foreach ($metadata as $key => $value) {
            $key = trim((string) $key);

            if ($key === '' || $value === null) {
                continue;
            }

            if (is_scalar($value)) {
                $normalized[$key] = $value;
                continue;
            }

            $encoded = json_encode($value, JSON_UNESCAPED_SLASHES);

            if ($encoded !== false) {
                $normalized[$key] = $encoded;
            }
        }

        return $normalized;
    }

    /**
     * Look up the current state of a transaction by paymentReference.
     */
    public function verifyTransactionByReference(string $paymentReference): array
    {
        $query = http_build_query(['paymentReference' => $paymentReference]);

        return $this->request('GET', "/api/v2/merchant/transactions/query?{$query}");
    }

    /**
     * Look up by transactionReference (the reference Monnify itself returns).
     */
    public function getTransactionStatus(string $transactionReference): array
    {
        return $this->request('GET', '/api/v2/transactions/' . urlencode($transactionReference));
    }

    /**
     * Pay-with-bank-transfer: pull dynamic virtual account details for a transaction.
     */
    public function payWithBankTransfer(string $transactionReference, ?string $bankCode = null): array
    {
        $body = ['transactionReference' => $transactionReference];

        if ($bankCode) {
            $body['bankCode'] = $bankCode;
        }

        return $this->request('POST', '/api/v1/merchant/bank-transfer/init-payment', $body);
    }

    /**
     * Validate a bank account before disbursement/name enquiry.
     */
    public function validateBankAccount(string $accountNumber, string $bankCode): array
    {
        $query = http_build_query([
            'accountNumber' => $accountNumber,
            'bankCode' => $bankCode,
        ]);

        return $this->request('GET', "/api/v1/disbursements/account/validate?{$query}");
    }

    /**
     * Initiate a Monnify single transfer/disbursement.
     *
     * @param  array{
     *   amount: float|int,
     *   reference: string,
     *   narration: string,
     *   destinationBankCode: string,
     *   destinationAccountNumber: string,
     *   destinationAccountName: string,
     *   currency?: string,
     *   sourceAccountNumber?: string,
     *   async?: bool,
     *   senderInfo?: array<string,mixed>
     * }  $payload
     */
    public function initiateSingleTransfer(array $payload): array
    {
        $body = [
            'amount' => $payload['amount'],
            'reference' => $payload['reference'],
            'narration' => $payload['narration'],
            'destinationBankCode' => $payload['destinationBankCode'],
            'destinationAccountNumber' => $payload['destinationAccountNumber'],
            'destinationAccountName' => $payload['destinationAccountName'],
            'currency' => $payload['currency'] ?? config('monnify.currency', 'NGN'),
            'sourceAccountNumber' => $payload['sourceAccountNumber'] ?? config('monnify.disbursement.source_account_number'),
        ];

        if (array_key_exists('async', $payload)) {
            $body['async'] = (bool) $payload['async'];
        }

        if (! empty($payload['senderInfo'])) {
            $body['senderInfo'] = $payload['senderInfo'];
        }

        if (empty($body['sourceAccountNumber'])) {
            throw new RuntimeException('Monnify disbursement source account number is not configured.');
        }

        return $this->request('POST', '/api/v2/disbursements/single', $body);
    }

    public function authorizeSingleTransfer(string $reference, string $authorizationCode): array
    {
        return $this->request('POST', '/api/v2/disbursements/single/validate-otp', [
            'reference' => $reference,
            'authorizationCode' => $authorizationCode,
        ]);
    }

    public function resendSingleTransferOtp(string $reference): array
    {
        return $this->request('POST', '/api/v2/disbursements/single/resend-otp', [
            'reference' => $reference,
        ]);
    }

    public function getSingleTransferStatus(string $reference): array
    {
        $query = http_build_query(['reference' => $reference]);

        return $this->request('GET', "/api/v2/disbursements/single/summary?{$query}");
    }

    public function getDisbursementWalletBalance(?string $accountNumber = null): array
    {
        $accountNumber = $accountNumber ?: config('monnify.disbursement.source_account_number');

        if (! $accountNumber) {
            throw new RuntimeException('Monnify disbursement source account number is not configured.');
        }

        $query = http_build_query(['accountNumber' => $accountNumber]);

        return $this->request('GET', "/api/v2/disbursements/wallet-balance?{$query}");
    }

    // ---------------------------------------------------------------------
    // Internal HTTP helper
    // ---------------------------------------------------------------------

    /**
     * @param  array<string,mixed>  $body
     * @return array<string,mixed>
     */
    protected function request(string $method, string $path, array $body = []): array
    {
        $token = $this->getAccessToken();

        try {
            $request = Http::withToken($token)->acceptJson();

            $response = match (strtoupper($method)) {
                'GET'  => $request->get($this->baseUrl . $path),
                'POST' => $request->post($this->baseUrl . $path, $body),
                default => throw new RuntimeException("Unsupported HTTP method: {$method}"),
            };

            // If the token expired between cache hit and the request, refresh once and retry.
            if ($response->status() === 401) {
                $token = $this->getAccessToken(forceRefresh: true);
                $request = Http::withToken($token)->acceptJson();

                $response = match (strtoupper($method)) {
                    'GET'  => $request->get($this->baseUrl . $path),
                    'POST' => $request->post($this->baseUrl . $path, $body),
                };
            }

            $data = $response->json() ?? [];

            if (! $response->successful() || ! ($data['requestSuccessful'] ?? false)) {
                Log::warning('Monnify request failed', [
                    'path'   => $path,
                    'status' => $response->status(),
                    'body'   => $data,
                ]);

                throw new RuntimeException(
                    $data['responseMessage'] ?? 'Monnify request failed',
                    (int) ($data['responseCode'] ?? $response->status())
                );
            }

            return $data['responseBody'] ?? [];
        } catch (RequestException $e) {
            Log::error('Monnify HTTP error', ['error' => $e->getMessage()]);
            throw new RuntimeException('Monnify request error: ' . $e->getMessage());
        }
    }

    protected function ensureConfigured(): void
    {
        if ($this->apiKey === '' || $this->secretKey === '' || $this->contractCode === '') {
            throw new RuntimeException('Monnify credentials are not configured. Check your .env file.');
        }
    }
}
